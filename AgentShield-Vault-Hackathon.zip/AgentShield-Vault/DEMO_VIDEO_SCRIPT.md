# AgentShield Vault — 1:55 demo script

## 0:00–0:15 — Hook

**On screen:** Hero.

> Autonomous agents need credentials to deploy, investigate, and act. But a credential copied into an agent’s prompt, code, or memory becomes something the agent owns. AgentShield turns it into access the agent must earn.

## 0:15–0:30 — What is new

**On screen:** Capability strip, then the three product sections.

> AgentShield combines workload identity, per-secret least privilege, just-in-time leases, and persistent audit with post-quantum encryption. It is one control plane for the full credential lifecycle—not a cryptography animation.

## 0:30–1:05 — Show the real access flow

**Action:** Briefly open **Tutorial**, then close it. Store a clearly synthetic credential and request it with its allowed agent.

> The tutorial can orient a new operator without changing vault data. The actions I perform now are real FastAPI requests. AgentShield uses ML-KEM-768, HKDF-SHA256, and AES-256-GCM to store this synthetic credential. The allowed agent passes identity and policy checks, receives HTTP 200, and gets a 60-second agent-bound lease.

**Pause on:** `HTTP 200`.

> Now the same secret is requested by an unregistered attacker. The policy engine returns HTTP 403, no value is released, and the denial becomes audit evidence.

**Pause on:** `HTTP 403`, then the `100/100` report result.

## 1:05–1:25 — Show verifiable evidence

**Action:** Close the demo, scroll to Vault, click **Proof** on `AGENTSHIELD_DEMO_KEY`.

> This proof comes from the encrypted record itself: ML-KEM ciphertext size, authenticated payload size, nonce, and a SHA-256 fingerprint. `Plaintext field present` is false. Values never enter lists, proofs, audits, scores, or reports.

## 1:25–1:43 — Explain the quantum claim precisely

**Action:** Scroll to Security and switch the threat simulator.

> A cryptographically relevant quantum computer threatens RSA and elliptic-curve key establishment through Shor’s algorithm. AgentShield replaces that layer with standardized ML-KEM-768. We do not claim quantum computers break AES-256; AES-256-GCM remains our payload cipher.

## 1:43–1:55 — Close

**On screen:** Approved and denied audit rows.

> Today this is a working local prototype. With attested workload identity and HSM-backed keys, the same boundary can become production infrastructure. AgentShield makes secrets usable by agents without making secrets part of them.

## Recording checklist

- Use only a clearly synthetic presentation secret.
- Record at 1440×900 or 1920×1080, browser zoom 100%.
- Hide bookmarks, notifications, and personal tabs.
- Pause on HTTP 200, HTTP 403, `plaintext field present: false`, and the audit.
- Add captions and keep the final cut under two minutes.
