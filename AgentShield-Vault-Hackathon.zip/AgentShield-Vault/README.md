# AgentShield Vault

**The zero-trust, post-quantum security layer for autonomous AI agents.**

AI agents need credentials to do useful work, but embedding long-lived API keys in prompts, code, environment variables, or agent memory creates an ownership problem. AgentShield Vault keeps those values encrypted at rest and releases them only after an agent identity passes a per-secret policy check. Every approval and denial becomes durable, value-free audit evidence.

> Your AI agents need access. They should never own your secrets.

## Why it matters

- **Agent identity:** every access request names a registered workload.
- **Least privilege:** each secret has its own agent allowlist, UTC time window, and daily request limit.
- **Just-in-time access:** an approved request receives an agent-bound lease that expires in 60 seconds by default.
- **Post-quantum protection:** ML-KEM-768 establishes key material; HKDF-SHA256 derives a unique 256-bit key; AES-256-GCM encrypts and authenticates the value.
- **Operational lifecycle:** secrets can be rotated in place or revoked without removing prior audit events.
- **Clear product guidance:** an optional spotlight tutorial, ciphertext proof, accurate quantum-threat explainer, security score, and metadata-only downloadable report.

## Quick start

Python 3.11 or newer is recommended.

### Windows PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
$env:VAULT_AGENT_ID = "agent-demo-001"
uvicorn server:app --reload --host 127.0.0.1 --port 8001
```

### macOS or Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
export VAULT_AGENT_ID=agent-demo-001
uvicorn server:app --reload --host 127.0.0.1 --port 8001
```

Open [http://127.0.0.1:8001](http://127.0.0.1:8001). API documentation is at [http://127.0.0.1:8001/docs](http://127.0.0.1:8001/docs).

The first run creates an ML-KEM-768 keypair and local metadata stores. `liboqs-python` is preferred when available; modern `cryptography` is the automatic ML-KEM fallback. To select one explicitly, set `PQS_BACKEND=liboqs` or `PQS_BACKEND=cryptography` before starting.

See [INSTALLATION.md](INSTALLATION.md) for troubleshooting and backend details.

## Guided walkthrough

Click **Take the tutorial** in the hero or the floating **Tutorial** control. The five-step spotlight explains Store Secret, Vault List, Agent Access, and Security without creating records automatically.

For a live presentation, use a synthetic value: store it, inspect its ciphertext proof, request it with an allowed identity, repeat with the built-in unregistered attacker option to show HTTP 403, then download the metadata-only report. Every result comes from the real API. See [DEMO_VIDEO_SCRIPT.md](DEMO_VIDEO_SCRIPT.md) for the spoken flow.

## API

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/health` | Vault, backend, agent, audit, and score status |
| `POST` | `/agents` | Register an agent identity and permissions |
| `GET` | `/agents` | List agent metadata |
| `POST` | `/encrypt` | Encrypt a secret and attach a policy |
| `GET` | `/list_secrets` | List safe secret metadata only |
| `PUT/GET` | `/secret/{id}/policy` | Change or inspect the secret policy |
| `POST` | `/request_access` | Evaluate zero-trust policy and issue a short lease |
| `GET` | `/lease/{token}` | Use a still-valid agent-bound lease |
| `PUT` | `/secret/{id}` | Rotate and re-encrypt while keeping the ID/policy |
| `DELETE` | `/secret/{id}` | Revoke ciphertext while retaining audit history |
| `GET` | `/security_proof/{id}` | Ciphertext sizes, schema, and SHA-256 fingerprint |
| `GET` | `/audit` | Persistent metadata-only security events |
| `GET` | `/security_score` | Evidence-backed posture checks |
| `GET` | `/security_report` | Download-safe metadata report |

The original `/get_secret/{id}` endpoint remains available for backward compatibility and requires the configured `agent_id` header. New integrations should use `/request_access`.

## Example: policy-controlled access

```bash
curl -X POST http://127.0.0.1:8001/agents \
  -H "Content-Type: application/json" \
  -d '{"name":"Support Agent","id":"agent-support-001","description":"Resolves incidents","permissions":["SUPPORT_API_KEY"]}'

curl -X POST http://127.0.0.1:8001/encrypt \
  -H "Content-Type: application/json" \
  -d '{"name":"SUPPORT_API_KEY","value":"demo-only","allowed_agents":["agent-support-001"],"max_requests_per_day":10}'

curl -X POST http://127.0.0.1:8001/request_access \
  -H "Content-Type: application/json" \
  -d '{"secret_id":"<SECRET_ID>","agent_id":"agent-support-001","ttl_seconds":60}'
```

## Data at rest

| File | Contents |
|---|---|
| `vault_public.pem` | ML-KEM public key |
| `vault_private.pem` | ML-KEM private key; never commit it |
| `key_meta.json` | Algorithm/backend metadata |
| `secrets.json` | KEM ciphertext, nonce, AES-GCM ciphertext, and safe labels |
| `agents.json` | Agent identity metadata and permissions |
| `policies.json` | Per-secret allowlists and limits |
| `audit_log.json` | Decision metadata; never secret values |

All runtime files are ignored by Git. Back them up as one unit if you want to retain decryptability and history.

## Cryptographic construction

For each stored value:

1. ML-KEM-768 encapsulates a fresh shared secret to the vault public key.
2. HKDF-SHA256 derives a 32-byte key using the secret ID as salt.
3. AES-256-GCM encrypts the UTF-8 value with a fresh 12-byte nonce.
4. The secret ID and name are authenticated as additional data.
5. Only ciphertext, nonce, KEM encapsulation, algorithm metadata, and safe labels are persisted.

Rotation repeats the full encapsulation and encryption process with fresh randomness while preserving the record ID. Revocation deletes the encrypted record and its active policy, not previous audit events.

## Security boundaries

This is a working hackathon prototype, not a production identity provider or HSM:

- Agent IDs are demonstration identities. Production should verify workload identity using mTLS, SPIFFE/SPIRE, cloud workload identity, signed JWTs, or equivalent attestation.
- The private key is local. Production should place it in an HSM/KMS and separate key administration from secret administration.
- Leases are held in process memory, so restarting the API invalidates them. A multi-instance deployment needs a secure shared lease store.
- JSON persistence is appropriate for an inspectable local demo, not concurrent production traffic. Use a transactional database and append-only/tamper-evident audit sink.
- TLS is not configured by this local server. Terminate HTTPS before exposing it beyond loopback.
- The dashboard reveals an approved value only for the lease countdown. The API client remains responsible for keeping it out of logs, traces, prompts, and long-term agent memory.
- ML-KEM protects key establishment against the standardized post-quantum threat model. The simulator does **not** claim that quantum computers break AES-256.

## Validation

```bash
python -m pytest -q
```

The suite covers encryption/decryption, no-plaintext persistence, safe proofs, identity and policy decisions, daily limits, agent-bound lease expiry, authorized 200 vs attacker 403, rotation, revocation, audit retention, and value-free reports.

## Project guide

- [ARCHITECTURE.md](ARCHITECTURE.md) — trust boundaries and request sequence
- [PRESENTATION_FLOW.md](PRESENTATION_FLOW.md) — pitch deck and live-demo order
- [DEMO_VIDEO_SCRIPT.md](DEMO_VIDEO_SCRIPT.md) — sub-two-minute narration
- [INSTALLATION.md](INSTALLATION.md) — environment and troubleshooting
- [DEVPOST_SUBMISSION.md](DEVPOST_SUBMISSION.md) — submission-ready project story

Do not use real production credentials during judging. Enter a clearly synthetic value for the presentation.
